# Readme

The program uses Python(3.11.7 64-bit) language and utilizes following libs:

- import tkinter as tk

- import math

- import pandas as pd



## Instructions on how to run the code: 

You can use Vs Code with Python Core to run it. Apart from operations in task requirements, pressing 'r' can reset the canvas. 

